import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

import { authRouter }      from "./routes/auth.js";
import { companiesRouter } from "./routes/companies.js";
import { clientsRouter }   from "./routes/clients.js";
import { weaponsRouter }   from "./routes/weapons.js";
import { ammoRouter }      from "./routes/ammo.js";
import { schedulesRouter } from "./routes/schedules.js";
import { financeRouter }   from "./routes/finance.js";
import { documentsRouter } from "./routes/documents.js";
import { usersRouter }     from "./routes/users.js";
import { adminRouter }     from "./routes/admin.js";

const app = express();
const PORT = Number(process.env.PORT ?? 3001);

// ── Segurança ──────────────────────────────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN ?? "http://localhost:5173",
  credentials: true,
}));
app.use(rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Muitas requisições. Tente novamente em alguns minutos." },
}));

// ── Parsing ────────────────────────────────────────────────────────────────────
app.use(express.json());

// ── Health Check ───────────────────────────────────────────────────────────────
app.get("/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ── Rotas ──────────────────────────────────────────────────────────────────────
app.use("/auth",                                          authRouter);
app.use("/admin",                                         adminRouter);
app.use("/companies",                                     companiesRouter);
app.use("/companies/:companyId/clients",                  clientsRouter);
app.use("/companies/:companyId/weapons",                  weaponsRouter);
app.use("/companies/:companyId/ammo",                     ammoRouter);
app.use("/companies/:companyId/schedules",                schedulesRouter);
app.use("/companies/:companyId/finance",                  financeRouter);
app.use("/companies/:companyId/documents",                documentsRouter);
app.use("/companies/:companyId/users",                    usersRouter);

// ── Erro 404 ───────────────────────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: "Rota não encontrada." });
});

// ── Erro global ────────────────────────────────────────────────────────────────
app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(500).json({ error: "Erro interno do servidor." });
});

// ── Start ──────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🚀 StandControl API rodando em http://localhost:${PORT}`);
  console.log(`   Ambiente: ${process.env.NODE_ENV ?? "development"}`);
});

export default app;
