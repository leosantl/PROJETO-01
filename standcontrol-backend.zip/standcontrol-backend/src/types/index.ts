// ─── Planos ───────────────────────────────────────────────────────────────────
export type PlanId = "starter" | "professional" | "enterprise";

export interface Plan {
  id: PlanId;
  name: string;
  tagline: string;
  monthly_price: number;
  annual_price: number;
  max_clients: number | null;
  max_users: number | null;
  features: string[];
  highlighted: boolean;
}

// ─── Empresas ─────────────────────────────────────────────────────────────────
export type CompanyType = "Clube" | "Estande" | "Empresa";
export type CompanyStatus = "Ativa" | "Trial" | "Suspensa" | "Cancelada";

export interface Company {
  id: string;
  slug: string;
  name: string;
  type: CompanyType;
  responsible: string;
  email: string;
  phone?: string;
  cnpj?: string;
  city?: string;
  logo_initials: string;
  plan_id: PlanId;
  status: CompanyStatus;
  trial_ends_at?: string;
  created_at: string;
  updated_at: string;
}

// ─── Usuários ─────────────────────────────────────────────────────────────────
export type UserRole = "Administrador" | "Gerente" | "Operador" | "Financeiro" | "Instrutor";
export type UserStatus = "Ativo" | "Suspenso";

export interface AppUser {
  id: string;
  company_id: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  last_access_at?: string;
  created_at: string;
  updated_at: string;
}

// ─── Clientes ─────────────────────────────────────────────────────────────────
export type ClientStatus = "Ativo" | "Pendente" | "Inativo";

export interface Client {
  id: string;
  company_id: string;
  name: string;
  cpf?: string;
  cr?: string;
  phone?: string;
  email?: string;
  status: ClientStatus;
  preferred_caliber?: string;
  joined_at: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

// ─── Armas ────────────────────────────────────────────────────────────────────
export type WeaponStatus = "Operacional" | "Manutenção" | "Recolhida";

export interface Weapon {
  id: string;
  company_id: string;
  client_id?: string;
  brand: string;
  model: string;
  caliber: string;
  serial: string;
  status: WeaponStatus;
  registered_at: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

// ─── Munição ──────────────────────────────────────────────────────────────────
export interface AmmoStock {
  id: string;
  company_id: string;
  caliber: string;
  brand: string;
  stock: number;
  min_stock: number;
  last_entry_at?: string;
  created_at: string;
  updated_at: string;
}

export type AmmoMoveType = "Entrada" | "Saída";

export interface AmmoMovement {
  id: string;
  company_id: string;
  ammo_stock_id: string;
  type: AmmoMoveType;
  caliber: string;
  qty: number;
  responsible: string;
  notes?: string;
  moved_at: string;
  created_at: string;
}

// ─── Agenda ───────────────────────────────────────────────────────────────────
export type ScheduleType = "Treino" | "Avaliação" | "Curso" | "Reserva";
export type ScheduleStatus = "Confirmado" | "Em espera" | "Concluído" | "Cancelado";

export interface Schedule {
  id: string;
  company_id: string;
  client_id?: string;
  instructor_id?: string;
  title: string;
  type: ScheduleType;
  lane?: string;
  starts_at: string;
  duration_min: number;
  status: ScheduleStatus;
  notes?: string;
  created_at: string;
  updated_at: string;
}

// ─── Financeiro ───────────────────────────────────────────────────────────────
export type FinanceType = "Receita" | "Despesa";
export type FinanceStatus = "Compensado" | "Previsto" | "Atrasado";

export interface FinanceEntry {
  id: string;
  company_id: string;
  description: string;
  category: string;
  type: FinanceType;
  amount: number; // centavos
  status: FinanceStatus;
  due_date?: string;
  settled_at?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

// ─── Documentos ───────────────────────────────────────────────────────────────
export type DocType = "CR" | "CRAF" | "Certificado" | "Contrato" | "Outro";
export type DocStatus = "Válido" | "Vence em breve" | "Vencido";

export interface Document {
  id: string;
  company_id: string;
  client_id?: string;
  weapon_id?: string;
  name: string;
  type: DocType;
  issued_at: string;
  expires_at: string;
  status: DocStatus;
  file_url?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

// ─── Faturas SaaS ─────────────────────────────────────────────────────────────
export type InvoiceStatus = "Paga" | "Pendente" | "Atrasada";

export interface Invoice {
  id: string;
  company_id: string;
  amount: number;
  status: InvoiceStatus;
  due_date: string;
  paid_at?: string;
  description?: string;
  created_at: string;
  updated_at: string;
}

// ─── Auth ─────────────────────────────────────────────────────────────────────
export interface JwtPayload {
  sub: string;         // user id
  company_id: string;
  role: UserRole;
  is_super_admin?: boolean;
}
