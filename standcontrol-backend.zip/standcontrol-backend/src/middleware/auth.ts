import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import type { JwtPayload } from "../types/index.js";

declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

const secret = process.env.JWT_SECRET ?? "dev_secret_change_in_prod";

export function authenticate(req: Request, res: Response, next: NextFunction) {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Token não fornecido." });
    return;
  }
  try {
    const payload = jwt.verify(auth.slice(7), secret) as JwtPayload;
    req.user = payload;
    next();
  } catch {
    res.status(401).json({ error: "Token inválido ou expirado." });
  }
}

/** Garante que o usuário pertence à empresa da rota (:companyId). */
export function sameCompany(req: Request, res: Response, next: NextFunction) {
  const { companyId } = req.params;
  if (!req.user) { res.status(401).json({ error: "Não autenticado." }); return; }
  if (req.user.is_super_admin) { next(); return; }
  if (req.user.company_id !== companyId) {
    res.status(403).json({ error: "Acesso negado a esta empresa." });
    return;
  }
  next();
}

/** Apenas super-admins. */
export function superAdminOnly(req: Request, res: Response, next: NextFunction) {
  if (!req.user?.is_super_admin) {
    res.status(403).json({ error: "Acesso restrito a super-admins." });
    return;
  }
  next();
}

/** Verifica se o usuário tem ao menos um dos roles exigidos. */
export function requireRole(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) { res.status(401).json({ error: "Não autenticado." }); return; }
    if (req.user.is_super_admin) { next(); return; }
    if (!roles.includes(req.user.role)) {
      res.status(403).json({ error: `Requer perfil: ${roles.join(" ou ")}.` });
      return;
    }
    next();
  };
}

export function signToken(payload: JwtPayload): string {
  return jwt.sign(payload, secret, {
    expiresIn: (process.env.JWT_EXPIRES_IN ?? "7d") as jwt.SignOptions["expiresIn"],
  });
}
