import { Router } from "express";
import { query, queryOne } from "../db/pool.js";
import { authenticate, superAdminOnly } from "../middleware/auth.js";

export const adminRouter = Router();
adminRouter.use(authenticate, superAdminOnly);

// GET /admin/kpis — KPIs gerais da plataforma
adminRouter.get("/kpis", async (_req, res) => {
  const [companies] = await query<{
    active: string; trial: string; suspended: string; cancelled: string;
  }>(
    `SELECT
       COUNT(*) FILTER (WHERE status='Ativa')    AS active,
       COUNT(*) FILTER (WHERE status='Trial')    AS trial,
       COUNT(*) FILTER (WHERE status='Suspensa') AS suspended,
       COUNT(*) FILTER (WHERE status='Cancelada')AS cancelled
     FROM companies`
  );

  const [revenue] = await query<{ mrr: string; arr: string }>(
    `SELECT
       SUM(p.monthly_price) AS mrr,
       SUM(p.annual_price)  AS arr
     FROM companies c JOIN plans p ON p.id=c.plan_id
     WHERE c.status='Ativa'`
  );

  const [newThisMonth] = await query<{ count: string }>(
    `SELECT COUNT(*) FROM companies
     WHERE EXTRACT(MONTH FROM created_at)=EXTRACT(MONTH FROM NOW())
       AND EXTRACT(YEAR  FROM created_at)=EXTRACT(YEAR  FROM NOW())`
  );

  res.json({
    activeCompanies: +companies.active,
    trialCompanies:  +companies.trial,
    suspended:       +companies.suspended,
    cancelled:       +companies.cancelled,
    mrr:             +(revenue.mrr ?? 0),
    arr:             +(revenue.arr ?? 0),
    newCustomers:    +newThisMonth.count,
  });
});

// GET /admin/companies — todas as empresas com detalhes
adminRouter.get("/companies", async (_req, res) => {
  const rows = await query(
    `SELECT c.*, p.name AS plan_name, p.monthly_price,
       (SELECT COUNT(*) FROM app_users u WHERE u.company_id=c.id) AS user_count
     FROM companies c JOIN plans p ON p.id=c.plan_id
     ORDER BY c.created_at DESC`
  );
  res.json(rows);
});

// GET /admin/invoices — faturas de todos os tenants
adminRouter.get("/invoices", async (_req, res) => {
  const rows = await query(
    `SELECT i.*, c.name AS company_name, c.plan_id
     FROM invoices i JOIN companies c ON c.id=i.company_id
     ORDER BY i.due_date DESC`
  );
  res.json(rows);
});

// PATCH /admin/invoices/:id — marcar como paga, pendente, etc.
adminRouter.patch("/invoices/:id", async (req, res) => {
  const { status, paid_at } = req.body;
  if (!status) { res.status(400).json({ error: "status é obrigatório." }); return; }

  const row = await queryOne(
    `UPDATE invoices SET status=$1, paid_at=$2 WHERE id=$3 RETURNING *`,
    [status, paid_at ?? (status === "Paga" ? new Date().toISOString() : null), req.params.id]
  );
  if (!row) { res.status(404).json({ error: "Fatura não encontrada." }); return; }
  res.json(row);
});

// GET /admin/mrr-series — evolução do MRR
adminRouter.get("/mrr-series", async (_req, res) => {
  // Aproximação: conta planos ativos por mês via invoices pagas
  const rows = await query(
    `SELECT
       TO_CHAR(DATE_TRUNC('month', paid_at), 'Mon') AS month,
       SUM(amount) AS value
     FROM invoices
     WHERE status='Paga' AND paid_at IS NOT NULL
       AND paid_at >= NOW() - INTERVAL '6 months'
     GROUP BY DATE_TRUNC('month', paid_at)
     ORDER BY DATE_TRUNC('month', paid_at)`
  );
  res.json(rows);
});

// GET /admin/plans — lista planos
adminRouter.get("/plans", async (_req, res) => {
  const rows = await query(`SELECT * FROM plans ORDER BY monthly_price`);
  res.json(rows);
});
