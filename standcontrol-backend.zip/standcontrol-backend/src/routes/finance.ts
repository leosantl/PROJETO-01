import { Router } from "express";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import { authenticate, sameCompany, requireRole } from "../middleware/auth.js";

export const financeRouter = Router({ mergeParams: true });
financeRouter.use(authenticate, sameCompany);

const entrySchema = z.object({
  description: z.string().min(1),
  category: z.string().min(1),
  type: z.enum(["Receita", "Despesa"]),
  amount: z.number().int().positive(), // centavos
  status: z.enum(["Compensado", "Previsto", "Atrasado"]).default("Previsto"),
  due_date: z.string().optional().nullable(),
  notes: z.string().optional(),
});

// GET /companies/:companyId/finance
financeRouter.get("/", async (req, res) => {
  const { companyId } = req.params;
  const { type, status, month, year } = req.query as Record<string, string>;

  const conditions = ["company_id=$1"];
  const values: unknown[] = [companyId];

  if (type) { values.push(type); conditions.push(`type=$${values.length}`); }
  if (status) { values.push(status); conditions.push(`status=$${values.length}`); }
  if (month && year) {
    values.push(parseInt(month), parseInt(year));
    conditions.push(`EXTRACT(MONTH FROM COALESCE(due_date,created_at::DATE))=$${values.length-1}`);
    conditions.push(`EXTRACT(YEAR  FROM COALESCE(due_date,created_at::DATE))=$${values.length}`);
  }

  const rows = await query(
    `SELECT * FROM finance_entries WHERE ${conditions.join(" AND ")} ORDER BY due_date DESC NULLS LAST`,
    values
  );
  res.json(rows);
});

// GET /companies/:companyId/finance/cashflow — receitas vs despesas por mês
financeRouter.get("/cashflow", async (req, res) => {
  const rows = await query(
    `SELECT
       TO_CHAR(DATE_TRUNC('month', COALESCE(due_date, created_at::DATE)), 'Mon') AS month,
       SUM(amount) FILTER (WHERE type='Receita') AS income,
       SUM(amount) FILTER (WHERE type='Despesa') AS expenses
     FROM finance_entries
     WHERE company_id=$1
       AND COALESCE(due_date, created_at::DATE) >= NOW() - INTERVAL '6 months'
     GROUP BY DATE_TRUNC('month', COALESCE(due_date, created_at::DATE))
     ORDER BY DATE_TRUNC('month', COALESCE(due_date, created_at::DATE))`,
    [req.params.companyId]
  );
  res.json(rows);
});

// GET /companies/:companyId/finance/:id
financeRouter.get("/:id", async (req, res) => {
  const row = await queryOne(
    `SELECT * FROM finance_entries WHERE id=$1 AND company_id=$2`,
    [req.params.id, req.params.companyId]
  );
  if (!row) { res.status(404).json({ error: "Lançamento não encontrado." }); return; }
  res.json(row);
});

// POST /companies/:companyId/finance
financeRouter.post(
  "/",
  requireRole("Administrador", "Gerente", "Financeiro"),
  async (req, res) => {
    const parsed = entrySchema.safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }
    const d = parsed.data;

    const row = await queryOne(
      `INSERT INTO finance_entries (company_id,description,category,type,amount,status,due_date,notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.params.companyId, d.description, d.category, d.type, d.amount, d.status, d.due_date, d.notes]
    );
    res.status(201).json(row);
  }
);

// PATCH /companies/:companyId/finance/:id
financeRouter.patch(
  "/:id",
  requireRole("Administrador", "Gerente", "Financeiro"),
  async (req, res) => {
    const { id, companyId } = req.params;
    const allowed = ["description","category","type","amount","status","due_date","settled_at","notes"];
    const updates: string[] = [];
    const values: unknown[] = [];

    for (const key of allowed) {
      if (key in req.body) { values.push(req.body[key]); updates.push(`${key}=$${values.length}`); }
    }
    if (!updates.length) { res.status(400).json({ error: "Nenhum campo para atualizar." }); return; }

    values.push(id, companyId);
    const row = await queryOne(
      `UPDATE finance_entries SET ${updates.join(",")} WHERE id=$${values.length-1} AND company_id=$${values.length} RETURNING *`,
      values
    );
    if (!row) { res.status(404).json({ error: "Lançamento não encontrado." }); return; }
    res.json(row);
  }
);

// DELETE /companies/:companyId/finance/:id
financeRouter.delete(
  "/:id",
  requireRole("Administrador", "Financeiro"),
  async (req, res) => {
    const result = await query(
      `DELETE FROM finance_entries WHERE id=$1 AND company_id=$2 RETURNING id`,
      [req.params.id, req.params.companyId]
    );
    if (!result.length) { res.status(404).json({ error: "Lançamento não encontrado." }); return; }
    res.status(204).end();
  }
);
