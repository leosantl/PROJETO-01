import { Router } from "express";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { query, queryOne } from "../db/pool.js";
import { authenticate, sameCompany, requireRole } from "../middleware/auth.js";

export const usersRouter = Router({ mergeParams: true });
usersRouter.use(authenticate, sameCompany);

// GET /companies/:companyId/users
usersRouter.get("/", async (req, res) => {
  const rows = await query(
    `SELECT id,company_id,name,email,role,status,last_access_at,created_at,updated_at
     FROM app_users WHERE company_id=$1 ORDER BY name`,
    [req.params.companyId]
  );
  res.json(rows);
});

// GET /companies/:companyId/users/me
usersRouter.get("/me", (req, res) => {
  res.json(req.user);
});

const createUserSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6),
  role: z.enum(["Administrador","Gerente","Operador","Financeiro","Instrutor"]),
});

// POST /companies/:companyId/users
usersRouter.post(
  "/",
  requireRole("Administrador", "Gerente"),
  async (req, res) => {
    const parsed = createUserSchema.safeParse(req.body);
    if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }
    const d = parsed.data;

    const password_hash = await bcrypt.hash(d.password, 10);
    const user = await queryOne(
      `INSERT INTO app_users (company_id,name,email,password_hash,role)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING id,company_id,name,email,role,status,created_at`,
      [req.params.companyId, d.name, d.email, password_hash, d.role]
    ).catch(() => null);

    if (!user) { res.status(409).json({ error: "E-mail já cadastrado nesta empresa." }); return; }
    res.status(201).json(user);
  }
);

// PATCH /companies/:companyId/users/:id
usersRouter.patch(
  "/:id",
  requireRole("Administrador"),
  async (req, res) => {
    const { id, companyId } = req.params;
    const allowed = ["name","email","role","status"];
    const updates: string[] = [];
    const values: unknown[] = [];

    for (const key of allowed) {
      if (key in req.body) { values.push(req.body[key]); updates.push(`${key}=$${values.length}`); }
    }

    if ("password" in req.body && req.body.password) {
      values.push(await bcrypt.hash(req.body.password, 10));
      updates.push(`password_hash=$${values.length}`);
    }

    if (!updates.length) { res.status(400).json({ error: "Nenhum campo para atualizar." }); return; }
    values.push(id, companyId);

    const user = await queryOne(
      `UPDATE app_users SET ${updates.join(",")}
       WHERE id=$${values.length-1} AND company_id=$${values.length}
       RETURNING id,company_id,name,email,role,status,last_access_at,updated_at`,
      values
    );
    if (!user) { res.status(404).json({ error: "Usuário não encontrado." }); return; }
    res.json(user);
  }
);

// DELETE /companies/:companyId/users/:id
usersRouter.delete(
  "/:id",
  requireRole("Administrador"),
  async (req, res) => {
    if (req.user?.sub === req.params.id) {
      res.status(400).json({ error: "Você não pode excluir sua própria conta." });
      return;
    }
    const result = await query(
      `DELETE FROM app_users WHERE id=$1 AND company_id=$2 RETURNING id`,
      [req.params.id, req.params.companyId]
    );
    if (!result.length) { res.status(404).json({ error: "Usuário não encontrado." }); return; }
    res.status(204).end();
  }
);
