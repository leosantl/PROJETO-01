import { Router } from "express";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import { authenticate, sameCompany } from "../middleware/auth.js";

export const documentsRouter = Router({ mergeParams: true });
documentsRouter.use(authenticate, sameCompany);

const docSchema = z.object({
  client_id: z.string().optional().nullable(),
  weapon_id: z.string().optional().nullable(),
  name: z.string().min(1),
  type: z.enum(["CR", "CRAF", "Certificado", "Contrato", "Outro"]),
  issued_at: z.string(),
  expires_at: z.string(),
  file_url: z.string().url().optional().nullable(),
  notes: z.string().optional(),
});

function calcStatus(expiresAt: string): "Válido" | "Vence em breve" | "Vencido" {
  const exp = new Date(expiresAt);
  const now = new Date();
  const diffDays = Math.ceil((exp.getTime() - now.getTime()) / 86_400_000);
  if (diffDays < 0) return "Vencido";
  if (diffDays <= 30) return "Vence em breve";
  return "Válido";
}

// GET /companies/:companyId/documents
documentsRouter.get("/", async (req, res) => {
  const { companyId } = req.params;
  const { status, type, client_id } = req.query as Record<string, string>;

  const conditions = ["d.company_id=$1"];
  const values: unknown[] = [companyId];

  // Recalcula status dinamicamente
  const statusExpr = `
    CASE
      WHEN expires_at < CURRENT_DATE THEN 'Vencido'
      WHEN expires_at < CURRENT_DATE + INTERVAL '30 days' THEN 'Vence em breve'
      ELSE 'Válido'
    END`;

  if (status) { values.push(status); conditions.push(`(${statusExpr}) = $${values.length}`); }
  if (type) { values.push(type); conditions.push(`d.type=$${values.length}`); }
  if (client_id) { values.push(client_id); conditions.push(`d.client_id=$${values.length}`); }

  const rows = await query(
    `SELECT d.*,
       ${statusExpr} AS computed_status,
       c.name AS client_name,
       w.serial AS weapon_serial
     FROM documents d
     LEFT JOIN clients c ON c.id=d.client_id
     LEFT JOIN weapons w ON w.id=d.weapon_id
     WHERE ${conditions.join(" AND ")}
     ORDER BY d.expires_at ASC`,
    values
  );
  res.json(rows);
});

// GET /companies/:companyId/documents/:id
documentsRouter.get("/:id", async (req, res) => {
  const row = await queryOne(
    `SELECT d.*, c.name AS client_name, w.serial AS weapon_serial
     FROM documents d
     LEFT JOIN clients c ON c.id=d.client_id
     LEFT JOIN weapons w ON w.id=d.weapon_id
     WHERE d.id=$1 AND d.company_id=$2`,
    [req.params.id, req.params.companyId]
  );
  if (!row) { res.status(404).json({ error: "Documento não encontrado." }); return; }
  res.json(row);
});

// POST /companies/:companyId/documents
documentsRouter.post("/", async (req, res) => {
  const parsed = docSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }
  const d = parsed.data;
  const status = calcStatus(d.expires_at);

  const row = await queryOne(
    `INSERT INTO documents (company_id,client_id,weapon_id,name,type,issued_at,expires_at,status,file_url,notes)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [req.params.companyId, d.client_id, d.weapon_id, d.name, d.type,
     d.issued_at, d.expires_at, status, d.file_url, d.notes]
  );
  res.status(201).json(row);
});

// PATCH /companies/:companyId/documents/:id
documentsRouter.patch("/:id", async (req, res) => {
  const { id, companyId } = req.params;
  const allowed = ["client_id","weapon_id","name","type","issued_at","expires_at","file_url","notes"];
  const updates: string[] = [];
  const values: unknown[] = [];

  for (const key of allowed) {
    if (key in req.body) { values.push(req.body[key]); updates.push(`${key}=$${values.length}`); }
  }

  // Recalcula status se expires_at mudou
  if ("expires_at" in req.body) {
    values.push(calcStatus(req.body.expires_at));
    updates.push(`status=$${values.length}`);
  }

  if (!updates.length) { res.status(400).json({ error: "Nenhum campo para atualizar." }); return; }
  values.push(id, companyId);

  const row = await queryOne(
    `UPDATE documents SET ${updates.join(",")} WHERE id=$${values.length-1} AND company_id=$${values.length} RETURNING *`,
    values
  );
  if (!row) { res.status(404).json({ error: "Documento não encontrado." }); return; }
  res.json(row);
});

// DELETE /companies/:companyId/documents/:id
documentsRouter.delete("/:id", async (req, res) => {
  const result = await query(
    `DELETE FROM documents WHERE id=$1 AND company_id=$2 RETURNING id`,
    [req.params.id, req.params.companyId]
  );
  if (!result.length) { res.status(404).json({ error: "Documento não encontrado." }); return; }
  res.status(204).end();
});
