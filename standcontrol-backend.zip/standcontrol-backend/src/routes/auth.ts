import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { queryOne } from "../db/pool.js";
import { signToken } from "../middleware/auth.js";
import type { AppUser } from "../types/index.js";

export const authRouter = Router();

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

/** POST /auth/login — login de usuário de empresa */
authRouter.post("/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Dados inválidos.", details: parsed.error.flatten() });
    return;
  }

  const { email, password } = parsed.data;
  const user = await queryOne<AppUser & { password_hash: string }>(
    `SELECT * FROM app_users WHERE email = $1 AND status = 'Ativo' LIMIT 1`,
    [email]
  );

  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    res.status(401).json({ error: "Credenciais inválidas." });
    return;
  }

  // Atualiza last_access_at
  await queryOne(
    `UPDATE app_users SET last_access_at = NOW() WHERE id = $1`,
    [user.id]
  );

  const token = signToken({
    sub: user.id,
    company_id: user.company_id,
    role: user.role,
  });

  const { password_hash: _, ...safeUser } = user;
  res.json({ token, user: safeUser });
});

/** POST /auth/admin/login — login de super-admin da plataforma */
authRouter.post("/admin/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Dados inválidos." });
    return;
  }

  const { email, password } = parsed.data;
  const admin = await queryOne<{ id: string; name: string; email: string; password_hash: string }>(
    `SELECT * FROM super_admins WHERE email = $1 LIMIT 1`,
    [email]
  );

  if (!admin || !(await bcrypt.compare(password, admin.password_hash))) {
    res.status(401).json({ error: "Credenciais inválidas." });
    return;
  }

  const token = signToken({
    sub: admin.id,
    company_id: "__admin__",
    role: "Administrador",
    is_super_admin: true,
  });

  res.json({ token, user: { id: admin.id, name: admin.name, email: admin.email } });
});
