import { Router } from "express";
import { z } from "zod";
import { query, queryOne, pool } from "../db/pool.js";
import { authenticate, sameCompany } from "../middleware/auth.js";

export const ammoRouter = Router({ mergeParams: true });
ammoRouter.use(authenticate, sameCompany);

// ── Estoque ───────────────────────────────────────────────────────────────────
// GET /companies/:companyId/ammo/stock
ammoRouter.get("/stock", async (req, res) => {
  const rows = await query(
    `SELECT *, (stock < min_stock) AS below_minimum
     FROM ammo_stock WHERE company_id=$1 ORDER BY caliber`,
    [req.params.companyId]
  );
  res.json(rows);
});

// POST /companies/:companyId/ammo/stock
ammoRouter.post("/stock", async (req, res) => {
  const schema = z.object({
    caliber: z.string().min(1),
    brand: z.string().min(1),
    stock: z.number().int().min(0),
    min_stock: z.number().int().min(0),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }
  const d = parsed.data;

  const row = await queryOne(
    `INSERT INTO ammo_stock (company_id,caliber,brand,stock,min_stock)
     VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (company_id,caliber,brand) DO UPDATE
       SET stock=EXCLUDED.stock, min_stock=EXCLUDED.min_stock
     RETURNING *`,
    [req.params.companyId, d.caliber, d.brand, d.stock, d.min_stock]
  );
  res.status(201).json(row);
});

// ── Movimentações ─────────────────────────────────────────────────────────────
const moveSchema = z.object({
  ammo_stock_id: z.string().min(1),
  type: z.enum(["Entrada", "Saída"]),
  qty: z.number().int().positive(),
  responsible: z.string().min(1),
  notes: z.string().optional(),
  moved_at: z.string().optional(),
});

// GET /companies/:companyId/ammo/movements
ammoRouter.get("/movements", async (req, res) => {
  const { limit = "50", page = "1" } = req.query as Record<string, string>;
  const offset = (parseInt(page) - 1) * parseInt(limit);

  const rows = await query(
    `SELECT m.*, s.brand
     FROM ammo_movements m
     JOIN ammo_stock s ON s.id = m.ammo_stock_id
     WHERE m.company_id=$1
     ORDER BY m.moved_at DESC LIMIT $2 OFFSET $3`,
    [req.params.companyId, parseInt(limit), offset]
  );
  res.json(rows);
});

// POST /companies/:companyId/ammo/movements
ammoRouter.post("/movements", async (req, res) => {
  const parsed = moveSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }
  const d = parsed.data;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Verifica estoque atual
    const stock = await client.query(
      `SELECT stock FROM ammo_stock WHERE id=$1 AND company_id=$2 FOR UPDATE`,
      [d.ammo_stock_id, req.params.companyId]
    );
    if (!stock.rows.length) {
      await client.query("ROLLBACK");
      res.status(404).json({ error: "Estoque não encontrado." });
      return;
    }

    const currentStock: number = stock.rows[0].stock;
    if (d.type === "Saída" && currentStock < d.qty) {
      await client.query("ROLLBACK");
      res.status(422).json({ error: `Estoque insuficiente. Disponível: ${currentStock} unidades.` });
      return;
    }

    const delta = d.type === "Entrada" ? d.qty : -d.qty;
    const caliber = await client.query(
      `UPDATE ammo_stock SET stock = stock + $1, last_entry_at = CASE WHEN $2 THEN CURRENT_DATE ELSE last_entry_at END
       WHERE id=$3 RETURNING caliber`,
      [delta, d.type === "Entrada", d.ammo_stock_id]
    );

    const move = await client.query(
      `INSERT INTO ammo_movements (company_id,ammo_stock_id,type,caliber,qty,responsible,notes,moved_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [req.params.companyId, d.ammo_stock_id, d.type,
       caliber.rows[0].caliber, d.qty, d.responsible, d.notes,
       d.moved_at ?? new Date().toISOString()]
    );

    await client.query("COMMIT");
    res.status(201).json(move.rows[0]);
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
});
