import { Router } from "express";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import { authenticate, sameCompany } from "../middleware/auth.js";

export const weaponsRouter = Router({ mergeParams: true });
weaponsRouter.use(authenticate, sameCompany);

const weaponSchema = z.object({
  client_id: z.string().optional().nullable(),
  brand: z.string().min(1),
  model: z.string().min(1),
  caliber: z.string().min(1),
  serial: z.string().min(1),
  status: z.enum(["Operacional", "Manutenção", "Recolhida"]).default("Operacional"),
  registered_at: z.string().optional(),
  notes: z.string().optional(),
});

// GET /companies/:companyId/weapons
weaponsRouter.get("/", async (req, res) => {
  const { companyId } = req.params;
  const { status, caliber, search } = req.query as Record<string, string>;

  const conditions = ["w.company_id = $1"];
  const values: unknown[] = [companyId];

  if (status) { values.push(status); conditions.push(`w.status = $${values.length}`); }
  if (caliber) { values.push(caliber); conditions.push(`w.caliber = $${values.length}`); }
  if (search) {
    values.push(`%${search}%`);
    conditions.push(`(w.brand ILIKE $${values.length} OR w.model ILIKE $${values.length} OR w.serial ILIKE $${values.length})`);
  }

  const rows = await query(
    `SELECT w.*, c.name AS client_name
     FROM weapons w
     LEFT JOIN clients c ON c.id = w.client_id
     WHERE ${conditions.join(" AND ")}
     ORDER BY w.brand, w.model`,
    values
  );
  res.json(rows);
});

// GET /companies/:companyId/weapons/:id
weaponsRouter.get("/:id", async (req, res) => {
  const weapon = await queryOne(
    `SELECT w.*, c.name AS client_name
     FROM weapons w LEFT JOIN clients c ON c.id=w.client_id
     WHERE w.id=$1 AND w.company_id=$2`,
    [req.params.id, req.params.companyId]
  );
  if (!weapon) { res.status(404).json({ error: "Arma não encontrada." }); return; }
  res.json(weapon);
});

// POST /companies/:companyId/weapons
weaponsRouter.post("/", async (req, res) => {
  const parsed = weaponSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }
  const d = parsed.data;

  const weapon = await queryOne(
    `INSERT INTO weapons (company_id,client_id,brand,model,caliber,serial,status,registered_at,notes)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [req.params.companyId, d.client_id, d.brand, d.model, d.caliber, d.serial,
     d.status, d.registered_at ?? new Date().toISOString().slice(0,10), d.notes]
  ).catch(() => null);

  if (!weapon) { res.status(409).json({ error: "Número de série já cadastrado nesta empresa." }); return; }
  res.status(201).json(weapon);
});

// PATCH /companies/:companyId/weapons/:id
weaponsRouter.patch("/:id", async (req, res) => {
  const { id, companyId } = req.params;
  const allowed = ["client_id","brand","model","caliber","serial","status","registered_at","notes"];
  const updates: string[] = [];
  const values: unknown[] = [];

  for (const key of allowed) {
    if (key in req.body) { values.push(req.body[key]); updates.push(`${key}=$${values.length}`); }
  }
  if (!updates.length) { res.status(400).json({ error: "Nenhum campo para atualizar." }); return; }

  values.push(id, companyId);
  const weapon = await queryOne(
    `UPDATE weapons SET ${updates.join(",")} WHERE id=$${values.length-1} AND company_id=$${values.length} RETURNING *`,
    values
  );
  if (!weapon) { res.status(404).json({ error: "Arma não encontrada." }); return; }
  res.json(weapon);
});

// DELETE /companies/:companyId/weapons/:id
weaponsRouter.delete("/:id", async (req, res) => {
  const result = await query(
    `DELETE FROM weapons WHERE id=$1 AND company_id=$2 RETURNING id`,
    [req.params.id, req.params.companyId]
  );
  if (!result.length) { res.status(404).json({ error: "Arma não encontrada." }); return; }
  res.status(204).end();
});
