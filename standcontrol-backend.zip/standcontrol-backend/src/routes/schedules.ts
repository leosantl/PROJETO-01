import { Router } from "express";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import { authenticate, sameCompany } from "../middleware/auth.js";

export const schedulesRouter = Router({ mergeParams: true });
schedulesRouter.use(authenticate, sameCompany);

const scheduleSchema = z.object({
  client_id: z.string().optional().nullable(),
  instructor_id: z.string().optional().nullable(),
  title: z.string().min(1),
  type: z.enum(["Treino", "Avaliação", "Curso", "Reserva"]),
  lane: z.string().optional(),
  starts_at: z.string().datetime({ offset: true }).or(z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/)),
  duration_min: z.number().int().positive().default(60),
  status: z.enum(["Confirmado", "Em espera", "Concluído", "Cancelado"]).default("Confirmado"),
  notes: z.string().optional(),
});

// GET /companies/:companyId/schedules
schedulesRouter.get("/", async (req, res) => {
  const { companyId } = req.params;
  const { date, status, type } = req.query as Record<string, string>;

  const conditions = ["s.company_id=$1"];
  const values: unknown[] = [companyId];

  if (date) {
    values.push(date);
    conditions.push(`DATE(s.starts_at) = $${values.length}`);
  }
  if (status) { values.push(status); conditions.push(`s.status=$${values.length}`); }
  if (type) { values.push(type); conditions.push(`s.type=$${values.length}`); }

  const rows = await query(
    `SELECT s.*,
       c.name AS client_name,
       u.name AS instructor_name
     FROM schedules s
     LEFT JOIN clients c ON c.id = s.client_id
     LEFT JOIN app_users u ON u.id = s.instructor_id
     WHERE ${conditions.join(" AND ")}
     ORDER BY s.starts_at ASC`,
    values
  );
  res.json(rows);
});

// GET /companies/:companyId/schedules/week-summary
schedulesRouter.get("/week-summary", async (req, res) => {
  const rows = await query(
    `SELECT TO_CHAR(DATE(starts_at),'Dy') AS day, COUNT(*) AS count
     FROM schedules
     WHERE company_id=$1
       AND starts_at >= NOW() - INTERVAL '6 days'
       AND starts_at <  NOW() + INTERVAL '1 day'
     GROUP BY DATE(starts_at)
     ORDER BY DATE(starts_at)`,
    [req.params.companyId]
  );
  res.json(rows);
});

// GET /companies/:companyId/schedules/:id
schedulesRouter.get("/:id", async (req, res) => {
  const row = await queryOne(
    `SELECT s.*, c.name AS client_name, u.name AS instructor_name
     FROM schedules s
     LEFT JOIN clients c ON c.id=s.client_id
     LEFT JOIN app_users u ON u.id=s.instructor_id
     WHERE s.id=$1 AND s.company_id=$2`,
    [req.params.id, req.params.companyId]
  );
  if (!row) { res.status(404).json({ error: "Agendamento não encontrado." }); return; }
  res.json(row);
});

// POST /companies/:companyId/schedules
schedulesRouter.post("/", async (req, res) => {
  const parsed = scheduleSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }
  const d = parsed.data;

  const row = await queryOne(
    `INSERT INTO schedules (company_id,client_id,instructor_id,title,type,lane,starts_at,duration_min,status,notes)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [req.params.companyId, d.client_id, d.instructor_id, d.title, d.type,
     d.lane, d.starts_at, d.duration_min, d.status, d.notes]
  );
  res.status(201).json(row);
});

// PATCH /companies/:companyId/schedules/:id
schedulesRouter.patch("/:id", async (req, res) => {
  const { id, companyId } = req.params;
  const allowed = ["client_id","instructor_id","title","type","lane","starts_at","duration_min","status","notes"];
  const updates: string[] = [];
  const values: unknown[] = [];

  for (const key of allowed) {
    if (key in req.body) { values.push(req.body[key]); updates.push(`${key}=$${values.length}`); }
  }
  if (!updates.length) { res.status(400).json({ error: "Nenhum campo para atualizar." }); return; }

  values.push(id, companyId);
  const row = await queryOne(
    `UPDATE schedules SET ${updates.join(",")} WHERE id=$${values.length-1} AND company_id=$${values.length} RETURNING *`,
    values
  );
  if (!row) { res.status(404).json({ error: "Agendamento não encontrado." }); return; }
  res.json(row);
});

// DELETE /companies/:companyId/schedules/:id
schedulesRouter.delete("/:id", async (req, res) => {
  const result = await query(
    `DELETE FROM schedules WHERE id=$1 AND company_id=$2 RETURNING id`,
    [req.params.id, req.params.companyId]
  );
  if (!result.length) { res.status(404).json({ error: "Agendamento não encontrado." }); return; }
  res.status(204).end();
});
