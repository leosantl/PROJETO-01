import { Router } from "express";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import { authenticate, sameCompany } from "../middleware/auth.js";

export const clientsRouter = Router({ mergeParams: true });
clientsRouter.use(authenticate, sameCompany);

const clientSchema = z.object({
  name: z.string().min(2),
  cpf: z.string().optional(),
  cr: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional(),
  status: z.enum(["Ativo", "Pendente", "Inativo"]).default("Pendente"),
  preferred_caliber: z.string().optional(),
  joined_at: z.string().optional(),
  notes: z.string().optional(),
});

// GET /companies/:companyId/clients
clientsRouter.get("/", async (req, res) => {
  const { companyId } = req.params;
  const { status, search, page = "1", limit = "50" } = req.query as Record<string, string>;

  const conditions: string[] = ["company_id = $1"];
  const values: unknown[] = [companyId];

  if (status) {
    values.push(status);
    conditions.push(`status = $${values.length}`);
  }
  if (search) {
    values.push(`%${search}%`);
    conditions.push(`(name ILIKE $${values.length} OR cr ILIKE $${values.length} OR email ILIKE $${values.length})`);
  }

  const offset = (parseInt(page) - 1) * parseInt(limit);
  values.push(parseInt(limit), offset);

  const rows = await query(
    `SELECT * FROM clients WHERE ${conditions.join(" AND ")}
     ORDER BY name ASC LIMIT $${values.length - 1} OFFSET $${values.length}`,
    values
  );

  const [{ count }] = await query<{ count: string }>(
    `SELECT COUNT(*) FROM clients WHERE ${conditions.slice(0, -values.length + 3 + (status ? 1 : 0) + (search ? 1 : 0)).join(" AND ")}`,
    values.slice(0, -2)
  );

  res.json({ data: rows, total: +count, page: +page, limit: +limit });
});

// GET /companies/:companyId/clients/:id
clientsRouter.get("/:id", async (req, res) => {
  const client = await queryOne(
    `SELECT c.*, 
       json_agg(DISTINCT w.*) FILTER (WHERE w.id IS NOT NULL) AS weapons,
       json_agg(DISTINCT d.*) FILTER (WHERE d.id IS NOT NULL) AS documents
     FROM clients c
     LEFT JOIN weapons w ON w.client_id = c.id
     LEFT JOIN documents d ON d.client_id = c.id
     WHERE c.id = $1 AND c.company_id = $2
     GROUP BY c.id`,
    [req.params.id, req.params.companyId]
  );
  if (!client) { res.status(404).json({ error: "Cliente não encontrado." }); return; }
  res.json(client);
});

// POST /companies/:companyId/clients
clientsRouter.post("/", async (req, res) => {
  const parsed = clientSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }
  const d = parsed.data;

  const client = await queryOne(
    `INSERT INTO clients (company_id,name,cpf,cr,phone,email,status,preferred_caliber,joined_at,notes)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [req.params.companyId, d.name, d.cpf, d.cr, d.phone, d.email,
     d.status, d.preferred_caliber, d.joined_at ?? new Date().toISOString().slice(0,10), d.notes]
  );
  res.status(201).json(client);
});

// PATCH /companies/:companyId/clients/:id
clientsRouter.patch("/:id", async (req, res) => {
  const { id, companyId } = req.params;
  const allowed = ["name","cpf","cr","phone","email","status","preferred_caliber","joined_at","notes"];
  const updates: string[] = [];
  const values: unknown[] = [];

  for (const key of allowed) {
    if (key in req.body) {
      values.push(req.body[key]);
      updates.push(`${key} = $${values.length}`);
    }
  }
  if (!updates.length) { res.status(400).json({ error: "Nenhum campo para atualizar." }); return; }

  values.push(id, companyId);
  const client = await queryOne(
    `UPDATE clients SET ${updates.join(",")}
     WHERE id = $${values.length - 1} AND company_id = $${values.length} RETURNING *`,
    values
  );
  if (!client) { res.status(404).json({ error: "Cliente não encontrado." }); return; }
  res.json(client);
});

// DELETE /companies/:companyId/clients/:id
clientsRouter.delete("/:id", async (req, res) => {
  const result = await query(
    `DELETE FROM clients WHERE id=$1 AND company_id=$2 RETURNING id`,
    [req.params.id, req.params.companyId]
  );
  if (!result.length) { res.status(404).json({ error: "Cliente não encontrado." }); return; }
  res.status(204).end();
});
