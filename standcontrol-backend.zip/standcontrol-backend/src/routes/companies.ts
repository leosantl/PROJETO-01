import { Router } from "express";
import { z } from "zod";
import { query, queryOne } from "../db/pool.js";
import { authenticate, superAdminOnly, sameCompany } from "../middleware/auth.js";

export const companiesRouter = Router();
companiesRouter.use(authenticate);

// ── GET /companies — lista todas (super-admin) ────────────────────────────────
companiesRouter.get("/", superAdminOnly, async (_req, res) => {
  const rows = await query(`
    SELECT c.*, p.name AS plan_name
    FROM companies c
    JOIN plans p ON p.id = c.plan_id
    ORDER BY c.created_at DESC
  `);
  res.json(rows);
});

// ── GET /companies/:companyId — detalhe ──────────────────────────────────────
companiesRouter.get("/:companyId", sameCompany, async (req, res) => {
  const company = await queryOne(
    `SELECT c.*, p.name AS plan_name, p.features, p.max_clients, p.max_users
     FROM companies c JOIN plans p ON p.id = c.plan_id
     WHERE c.id = $1`,
    [req.params.companyId]
  );
  if (!company) { res.status(404).json({ error: "Empresa não encontrada." }); return; }
  res.json(company);
});

const createSchema = z.object({
  slug: z.string().min(2).max(60).regex(/^[a-z0-9-]+$/),
  name: z.string().min(2),
  type: z.enum(["Clube", "Estande", "Empresa"]),
  responsible: z.string().min(2),
  email: z.string().email(),
  phone: z.string().optional(),
  cnpj: z.string().optional(),
  city: z.string().optional(),
  logo_initials: z.string().min(1).max(4).optional(),
  plan_id: z.enum(["starter", "professional", "enterprise"]),
});

// ── POST /companies — criar (super-admin) ─────────────────────────────────────
companiesRouter.post("/", superAdminOnly, async (req, res) => {
  const parsed = createSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.flatten() }); return; }

  const d = parsed.data;
  const company = await queryOne(
    `INSERT INTO companies (slug,name,type,responsible,email,phone,cnpj,city,logo_initials,plan_id,status,trial_ends_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'Trial', NOW() + INTERVAL '14 days')
     RETURNING *`,
    [d.slug, d.name, d.type, d.responsible, d.email, d.phone, d.cnpj, d.city,
     d.logo_initials ?? d.name.slice(0, 2).toUpperCase(), d.plan_id]
  );
  res.status(201).json(company);
});

// ── PATCH /companies/:companyId — atualizar ───────────────────────────────────
companiesRouter.patch("/:companyId", superAdminOnly, async (req, res) => {
  const { companyId } = req.params;
  const allowed = ["name","responsible","email","phone","cnpj","city","logo_initials","plan_id","status"];
  const updates: string[] = [];
  const values: unknown[] = [];

  for (const key of allowed) {
    if (key in req.body) {
      values.push(req.body[key]);
      updates.push(`${key} = $${values.length}`);
    }
  }

  if (!updates.length) { res.status(400).json({ error: "Nenhum campo para atualizar." }); return; }

  values.push(companyId);
  const company = await queryOne(
    `UPDATE companies SET ${updates.join(", ")} WHERE id = $${values.length} RETURNING *`,
    values
  );
  if (!company) { res.status(404).json({ error: "Empresa não encontrada." }); return; }
  res.json(company);
});

// ── GET /companies/:companyId/kpis — KPIs do dashboard ───────────────────────
companiesRouter.get("/:companyId/kpis", sameCompany, async (req, res) => {
  const { companyId } = req.params;

  const [clientCount] = await query<{ total: string; active: string }>(
    `SELECT COUNT(*) AS total,
            COUNT(*) FILTER (WHERE status='Ativo') AS active
     FROM clients WHERE company_id=$1`, [companyId]
  );

  const [weaponCount] = await query<{ total: string }>(
    `SELECT COUNT(*) AS total FROM weapons WHERE company_id=$1`, [companyId]
  );

  const [ammoTotal] = await query<{ total: string; low_stock: string }>(
    `SELECT SUM(stock) AS total,
            COUNT(*) FILTER (WHERE stock < min_stock) AS low_stock
     FROM ammo_stock WHERE company_id=$1`, [companyId]
  );

  const [scheduleToday] = await query<{ total: string }>(
    `SELECT COUNT(*) AS total FROM schedules
     WHERE company_id=$1 AND DATE(starts_at)=CURRENT_DATE`, [companyId]
  );

  const [docsExpiring] = await query<{ soon: string; expired: string }>(
    `SELECT COUNT(*) FILTER (WHERE status='Vence em breve') AS soon,
            COUNT(*) FILTER (WHERE status='Vencido') AS expired
     FROM documents WHERE company_id=$1`, [companyId]
  );

  const [finance] = await query<{ revenue: string; expenses: string; overdue: string }>(
    `SELECT
       SUM(amount) FILTER (WHERE type='Receita' AND status='Compensado') AS revenue,
       SUM(amount) FILTER (WHERE type='Despesa' AND status='Compensado') AS expenses,
       SUM(amount) FILTER (WHERE type='Despesa' AND status='Atrasado')   AS overdue
     FROM finance_entries
     WHERE company_id=$1
       AND EXTRACT(MONTH FROM COALESCE(due_date, created_at::DATE)) = EXTRACT(MONTH FROM NOW())`, [companyId]
  );

  res.json({
    clients: { total: +clientCount.total, active: +clientCount.active },
    weapons: { total: +weaponCount.total },
    ammo: { total: +(ammoTotal.total ?? 0), low_stock: +(ammoTotal.low_stock ?? 0) },
    schedules: { today: +scheduleToday.total },
    documents: { expiring_soon: +(docsExpiring.soon ?? 0), expired: +(docsExpiring.expired ?? 0) },
    finance: {
      revenue_month: +(finance.revenue ?? 0),
      expenses_month: +(finance.expenses ?? 0),
      overdue: +(finance.overdue ?? 0),
    },
  });
});
