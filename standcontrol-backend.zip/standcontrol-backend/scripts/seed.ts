/**
 * scripts/seed.ts
 * Popula o banco com dados iniciais (equivalente aos mocks do frontend).
 * Execute com: npm run db:seed
 */

import pg from "pg";
import bcrypt from "bcryptjs";
import "dotenv/config";

const { Client } = pg;

async function seed() {
  const db = new Client({ connectionString: process.env.DATABASE_URL });
  await db.connect();
  console.log("🌱 Iniciando seed…");

  // ── Planos ────────────────────────────────────────────────────────────────
  await db.query(`
    INSERT INTO plans (id, name, tagline, monthly_price, annual_price, max_clients, max_users, features, highlighted)
    VALUES
      ('starter',      'Starter',      'Para clubes em estruturação',       19900, 199000, 500,  5,    ARRAY['Cadastro de atiradores','Controle de acervo','Agenda básica','Suporte por e-mail'], FALSE),
      ('professional', 'Professional', 'Operação consolidada e crescimento', 59900, 599000, 5000, 20,   ARRAY['Tudo do Starter','Gestão documental com alertas','Financeiro completo','Relatórios avançados','Suporte prioritário'], TRUE),
      ('enterprise',   'Enterprise',   'Operações em larga escala',         149900, 1499000, NULL, NULL, ARRAY['Tudo do Professional','Multi-unidade','API privada (visual)','Gestor de conta dedicado','SLA 99,9%'], FALSE)
    ON CONFLICT (id) DO NOTHING;
  `);

  // ── Empresas ──────────────────────────────────────────────────────────────
  await db.query(`
    INSERT INTO companies (id, slug, name, type, responsible, email, plan_id, status, city, logo_initials)
    VALUES
      ('alpha',     'alpha',     'Clube Alpha Precision',   'Clube',   'Carlos R. Mendes',   'diretoria@alphaprecision.cac', 'enterprise',   'Ativa',    'São Paulo, SP',      'AP'),
      ('bravo',     'bravo',     'Clube Bravo Tático',      'Clube',   'Juliana F. Souza',   'contato@bravotatico.cac',      'professional', 'Ativa',    'Curitiba, PR',       'BT'),
      ('elite',     'elite',     'Estande Elite Shooting',  'Estande', 'Marcos A. Rocha',    'ops@eliteshooting.cac',        'professional', 'Ativa',    'Rio de Janeiro, RJ', 'ES'),
      ('precision', 'precision', 'Clube Precision Range',   'Clube',   'Helena Tavares',     'admin@precisionrange.cac',     'starter',      'Trial',    'Belo Horizonte, MG', 'PR'),
      ('sigma',     'sigma',     'Sigma Defense CAC',       'Empresa', 'Eduardo L. Pires',   'fiscal@sigmadefense.cac',      'enterprise',   'Ativa',    'Brasília, DF',       'SD'),
      ('delta',     'delta',     'Delta Despachante CAC',   'Empresa', 'Patrícia N. Lima',   'contato@deltacac.com.br',      'professional', 'Suspensa', 'Porto Alegre, RS',   'DD')
    ON CONFLICT (id) DO NOTHING;
  `);

  // ── Usuários da empresa Alpha ──────────────────────────────────────────────
  const hash = (p: string) => bcrypt.hashSync(p, 10);
  await db.query(`
    INSERT INTO app_users (id, company_id, name, email, password_hash, role, status)
    VALUES
      ('u1','alpha','Carlos R. Mendes',   'carlos@alphaprecision.cac',    $1, 'Administrador', 'Ativo'),
      ('u2','alpha','Beatriz Almeida',    'beatriz@alphaprecision.cac',   $2, 'Gerente',        'Ativo'),
      ('u3','alpha','Cap. Oliveira',      'instrutor@alphaprecision.cac', $3, 'Instrutor',      'Ativo'),
      ('u4','alpha','Patrícia Nogueira',  'financeiro@alphaprecision.cac',$4, 'Financeiro',     'Ativo'),
      ('u5','alpha','Vinícius Torres',    'operacao@alphaprecision.cac',  $5, 'Operador',       'Ativo'),
      ('u6','alpha','Júlia Rezende',      'estagio@alphaprecision.cac',   $6, 'Operador',       'Suspenso')
    ON CONFLICT (company_id, email) DO NOTHING;
  `, [hash('alpha123'), hash('alpha123'), hash('alpha123'), hash('alpha123'), hash('alpha123'), hash('alpha123')]);

  // Super-admin
  await db.query(`
    INSERT INTO super_admins (id, email, name, password_hash)
    VALUES ('sa1','admin@standcontrol.com.br','Super Admin', $1)
    ON CONFLICT (email) DO NOTHING;
  `, [hash('superadmin123')]);

  // ── Clientes (Alpha) ──────────────────────────────────────────────────────
  await db.query(`
    INSERT INTO clients (id, company_id, name, cpf, cr, phone, email, status, preferred_caliber, joined_at)
    VALUES
      ('c1','alpha','Ricardo S. Almeida',    '154.***.**9-22','SP-154329','(11) 98421-3320','ricardo.s@cac.br',    'Ativo',   '.380 ACP','2024-02-11'),
      ('c2','alpha','Marcus Vinícius Reis',  '882.***.**1-08','SP-188204','(11) 99114-5520','marcus.v@cac.br',     'Ativo',   '9mm',     '2023-08-09'),
      ('c3','alpha','Ana Paula Costa',       '431.***.**0-19','SP-243110','(11) 99875-2210','ana.costa@cac.br',    'Pendente','.40 S&W', '2025-01-22'),
      ('c4','alpha','Felipe O. Tavares',     '229.***.**4-33','SP-411220','(11) 98220-1108','felipe.t@cac.br',     'Ativo',   '9mm',     '2024-06-18'),
      ('c5','alpha','Roberta L. Carvalho',   '318.***.**5-71','SP-298311','(11) 99320-7740','roberta.c@cac.br',    'Ativo',   '.22 LR',  '2024-11-03'),
      ('c6','alpha','Diego N. Albuquerque',  '771.***.**3-44','SP-503118','(11) 98711-2030','diego.n@cac.br',      'Inativo', '.45 ACP', '2022-04-17'),
      ('c7','alpha','Larissa M. Pacheco',    '623.***.**8-90','SP-318092','(11) 99502-4411','larissa.p@cac.br',    'Ativo',   '9mm',     '2025-03-12'),
      ('c8','alpha','Henrique B. Salles',    '108.***.**1-67','SP-449201','(11) 98106-9090','henrique.s@cac.br',   'Ativo',   '.380 ACP','2023-12-04')
    ON CONFLICT (id) DO NOTHING;
  `);

  // ── Armas ─────────────────────────────────────────────────────────────────
  await db.query(`
    INSERT INTO weapons (id, company_id, client_id, brand, model, caliber, serial, status, registered_at)
    VALUES
      ('w1','alpha','c1','Taurus',         'G3C',       '9mm',     'TG3-492118', 'Operacional','2024-03-02'),
      ('w2','alpha','c2','Glock',          'G19 Gen5',  '9mm',     'GLK-771298', 'Operacional','2023-09-14'),
      ('w3','alpha','c4','CZ',             'P-09',      '9mm',     'CZP-208341', 'Manutenção', '2024-07-21'),
      ('w4','alpha','c3','Imbel',          'MD2',       '.40 S&W', 'IMB-114902', 'Operacional','2025-02-09'),
      ('w5','alpha','c8','Beretta',        '92FS',      '9mm',     'BR-922077',  'Operacional','2024-01-30'),
      ('w6','alpha','c5','Smith & Wesson', 'M&P Shield','.380 ACP','SW-388210',  'Recolhida',  '2022-10-11'),
      ('w7','alpha','c7','Sig Sauer',      'P226',      '9mm',     'SIG-661120', 'Operacional','2025-04-18')
    ON CONFLICT (id) DO NOTHING;
  `);

  // ── Estoque de Munição ────────────────────────────────────────────────────
  await db.query(`
    INSERT INTO ammo_stock (id, company_id, caliber, brand, stock, min_stock, last_entry_at)
    VALUES
      ('as1','alpha','9mm',     'CBC',               18420, 5000,'2026-06-08'),
      ('as2','alpha','.380 ACP','CBC',                9210, 3000,'2026-06-02'),
      ('as3','alpha','.40 S&W', 'Magtech',            4380, 2500,'2026-05-28'),
      ('as4','alpha','.22 LR',  'CBC',               12200, 4000,'2026-06-11'),
      ('as5','alpha','.45 ACP', 'Sellier & Bellot',   1840, 2000,'2026-05-20')
    ON CONFLICT (company_id, caliber, brand) DO NOTHING;
  `);

  // ── Movimentações de Munição ──────────────────────────────────────────────
  await db.query(`
    INSERT INTO ammo_movements (id, company_id, ammo_stock_id, type, caliber, qty, responsible, moved_at)
    VALUES
      ('m1','alpha','as1','Saída',   '9mm',     50,   'Ricardo S. Almeida',       '2026-06-14 14:20'),
      ('m2','alpha','as3','Saída',   '.40 S&W', 30,   'Ana Paula Costa',          '2026-06-14 13:10'),
      ('m3','alpha','as4','Entrada', '.22 LR',  2000, 'Compra — NF 8821',         '2026-06-13 18:42'),
      ('m4','alpha','as1','Saída',   '9mm',     100,  'Treino — Cap. Oliveira',   '2026-06-13 11:00'),
      ('m5','alpha','as2','Saída',   '.380 ACP',25,   'Felipe O. Tavares',        '2026-06-12 16:55')
    ON CONFLICT (id) DO NOTHING;
  `);

  // ── Agenda ────────────────────────────────────────────────────────────────
  await db.query(`
    INSERT INTO schedules (id, company_id, client_id, instructor_id, title, type, lane, starts_at, duration_min, status)
    VALUES
      ('s1','alpha','c8', NULL, 'Treino livre',             'Treino',    'Pista 02','2026-06-14 08:00', 60, 'Concluído'),
      ('s2','alpha','c7', 'u3', 'Avaliação técnica CR',     'Avaliação', 'Pista 01','2026-06-14 10:30', 90, 'Concluído'),
      ('s3','alpha','c3', NULL, 'Treino .40',               'Treino',    'Pista 04','2026-06-14 13:10', 60, 'Em espera'),
      ('s4','alpha','c1', NULL, 'Treino 9mm',               'Treino',    'Pista 03','2026-06-14 14:00', 60, 'Confirmado'),
      ('s5','alpha', NULL,'u3', 'Curso de Defesa Pessoal',  'Curso',     'Pista 01','2026-06-14 15:30',120, 'Confirmado'),
      ('s6','alpha', NULL,NULL, 'Reserva privada',          'Reserva',   'Pista 05','2026-06-14 18:00', 60, 'Confirmado')
    ON CONFLICT (id) DO NOTHING;
  `);

  // ── Financeiro ────────────────────────────────────────────────────────────
  await db.query(`
    INSERT INTO finance_entries (id, company_id, description, category, type, amount, status, due_date)
    VALUES
      ('f1','alpha','Mensalidades — Junho',         'Assinaturas', 'Receita',  2840000,'Compensado','2026-06-13'),
      ('f2','alpha','Venda de munição 9mm',          'Produtos',    'Receita',   418000,'Compensado','2026-06-12'),
      ('f3','alpha','Aluguel do estande',            'Operacional', 'Despesa',   820000,'Compensado','2026-06-10'),
      ('f4','alpha','Folha de pagamento',            'Pessoal',     'Despesa',  1460000,'Compensado','2026-06-09'),
      ('f5','alpha','Curso de Defesa — Turma 04',   'Serviços',    'Receita',   620000,'Compensado','2026-06-08'),
      ('f6','alpha','Energia elétrica',              'Operacional', 'Despesa',   284000,'Previsto',  '2026-06-20'),
      ('f7','alpha','Fornecedor — CBC',              'Estoque',     'Despesa',  1890000,'Atrasado',  '2026-06-01')
    ON CONFLICT (id) DO NOTHING;
  `);

  // ── Documentos ────────────────────────────────────────────────────────────
  await db.query(`
    INSERT INTO documents (id, company_id, client_id, weapon_id, name, type, issued_at, expires_at, status)
    VALUES
      ('d1','alpha','c1',NULL,'CR — Ricardo S. Almeida',          'CR',         '2021-07-12','2026-07-12','Vence em breve'),
      ('d2','alpha','c1','w1','CRAF — Taurus G3C (TG3-492118)',   'CRAF',       '2024-03-02','2026-07-02','Vence em breve'),
      ('d3','alpha','c2',NULL,'CR — Marcus Vinícius',             'CR',         '2022-01-20','2027-01-20','Válido'),
      ('d4','alpha','c4',NULL,'Certificado Curso Defesa',         'Certificado','2024-06-10','2027-06-10','Válido'),
      ('d5','alpha','c8',NULL,'Contrato Anual — Estande',         'Contrato',   '2026-01-01','2026-12-31','Válido'),
      ('d6','alpha','c2','w2','CRAF — Glock G19 (GLK-771298)',    'CRAF',       '2020-09-14','2026-05-14','Vencido')
    ON CONFLICT (id) DO NOTHING;
  `);

  // ── Faturas SaaS ──────────────────────────────────────────────────────────
  await db.query(`
    INSERT INTO invoices (id, company_id, amount, status, due_date, description)
    VALUES
      ('inv1','alpha',    149900,'Paga',    '2026-06-01','Enterprise — Junho/2026'),
      ('inv2','sigma',    149900,'Paga',    '2026-06-01','Enterprise — Junho/2026'),
      ('inv3','bravo',     59900,'Paga',    '2026-06-03','Professional — Junho/2026'),
      ('inv4','elite',     59900,'Pendente','2026-06-10','Professional — Junho/2026'),
      ('inv5','delta',     59900,'Atrasada','2026-05-28','Professional — Maio/2026'),
      ('inv6','precision',     0,'Pendente','2026-06-22','Trial — sem cobrança')
    ON CONFLICT (id) DO NOTHING;
  `);

  console.log("✅ Seed concluído com sucesso.");
  await db.end();
}

seed().catch((err) => {
  console.error("❌ Erro no seed:", err);
  process.exit(1);
});
