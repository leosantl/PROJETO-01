/**
 * scripts/migrate.ts
 * Executa todas as migrações em ordem. Execute com: npm run db:migrate
 */

import pg from "pg";
import "dotenv/config";

const { Client } = pg;

const SQL = /* sql */ `
-- ─── Extensões ────────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── ENUMs ────────────────────────────────────────────────────────────────────
DO $$ BEGIN
  CREATE TYPE company_type    AS ENUM ('Clube', 'Estande', 'Empresa');
  CREATE TYPE company_status  AS ENUM ('Ativa', 'Trial', 'Suspensa', 'Cancelada');
  CREATE TYPE plan_id         AS ENUM ('starter', 'professional', 'enterprise');
  CREATE TYPE user_role       AS ENUM ('Administrador', 'Gerente', 'Operador', 'Financeiro', 'Instrutor');
  CREATE TYPE user_status     AS ENUM ('Ativo', 'Suspenso');
  CREATE TYPE client_status   AS ENUM ('Ativo', 'Pendente', 'Inativo');
  CREATE TYPE weapon_status   AS ENUM ('Operacional', 'Manutenção', 'Recolhida');
  CREATE TYPE ammo_move_type  AS ENUM ('Entrada', 'Saída');
  CREATE TYPE schedule_type   AS ENUM ('Treino', 'Avaliação', 'Curso', 'Reserva');
  CREATE TYPE schedule_status AS ENUM ('Confirmado', 'Em espera', 'Concluído', 'Cancelado');
  CREATE TYPE finance_type    AS ENUM ('Receita', 'Despesa');
  CREATE TYPE finance_status  AS ENUM ('Compensado', 'Previsto', 'Atrasado');
  CREATE TYPE invoice_status  AS ENUM ('Paga', 'Pendente', 'Atrasada');
  CREATE TYPE doc_type        AS ENUM ('CR', 'CRAF', 'Certificado', 'Contrato', 'Outro');
  CREATE TYPE doc_status      AS ENUM ('Válido', 'Vence em breve', 'Vencido');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

-- ─── Planos ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS plans (
  id              plan_id       PRIMARY KEY,
  name            TEXT          NOT NULL,
  tagline         TEXT          NOT NULL,
  monthly_price   INTEGER       NOT NULL,  -- centavos
  annual_price    INTEGER       NOT NULL,  -- centavos
  max_clients     INTEGER,                 -- NULL = ilimitado
  max_users       INTEGER,                 -- NULL = ilimitado
  features        TEXT[]        NOT NULL DEFAULT '{}',
  highlighted     BOOLEAN       NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── Empresas / Tenants ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS companies (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  slug            TEXT          UNIQUE NOT NULL,
  name            TEXT          NOT NULL,
  type            company_type  NOT NULL,
  responsible     TEXT          NOT NULL,
  email           TEXT          NOT NULL,
  phone           TEXT,
  cnpj            TEXT,
  city            TEXT,
  logo_initials   TEXT          NOT NULL DEFAULT '??',
  plan_id         plan_id       NOT NULL REFERENCES plans(id),
  status          company_status NOT NULL DEFAULT 'Trial',
  trial_ends_at   TIMESTAMPTZ,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── Usuários do sistema ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS app_users (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  company_id      TEXT          NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name            TEXT          NOT NULL,
  email           TEXT          NOT NULL,
  password_hash   TEXT          NOT NULL,
  role            user_role     NOT NULL DEFAULT 'Operador',
  status          user_status   NOT NULL DEFAULT 'Ativo',
  last_access_at  TIMESTAMPTZ,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  UNIQUE (company_id, email)
);

-- ─── Clientes / Atiradores ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clients (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  company_id      TEXT          NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name            TEXT          NOT NULL,
  cpf             TEXT,                    -- armazenado mascarado
  cr              TEXT,                    -- nº Certificado de Registro
  phone           TEXT,
  email           TEXT,
  status          client_status NOT NULL DEFAULT 'Pendente',
  preferred_caliber TEXT,
  joined_at       DATE          NOT NULL DEFAULT CURRENT_DATE,
  notes           TEXT,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── Armas ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS weapons (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  company_id      TEXT          NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  client_id       TEXT          REFERENCES clients(id) ON DELETE SET NULL,
  brand           TEXT          NOT NULL,
  model           TEXT          NOT NULL,
  caliber         TEXT          NOT NULL,
  serial          TEXT          NOT NULL,
  status          weapon_status NOT NULL DEFAULT 'Operacional',
  registered_at   DATE          NOT NULL DEFAULT CURRENT_DATE,
  notes           TEXT,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  UNIQUE (company_id, serial)
);

-- ─── Estoque de Munição ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ammo_stock (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  company_id      TEXT          NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  caliber         TEXT          NOT NULL,
  brand           TEXT          NOT NULL,
  stock           INTEGER       NOT NULL DEFAULT 0,
  min_stock       INTEGER       NOT NULL DEFAULT 0,
  last_entry_at   DATE,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  UNIQUE (company_id, caliber, brand)
);

-- ─── Movimentação de Munição ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ammo_movements (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  company_id      TEXT          NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  ammo_stock_id   TEXT          NOT NULL REFERENCES ammo_stock(id),
  type            ammo_move_type NOT NULL,
  caliber         TEXT          NOT NULL,
  qty             INTEGER       NOT NULL CHECK (qty > 0),
  responsible     TEXT          NOT NULL,
  notes           TEXT,
  moved_at        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── Agenda ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS schedules (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  company_id      TEXT          NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  client_id       TEXT          REFERENCES clients(id) ON DELETE SET NULL,
  instructor_id   TEXT          REFERENCES app_users(id) ON DELETE SET NULL,
  title           TEXT          NOT NULL,
  type            schedule_type NOT NULL,
  lane            TEXT,
  starts_at       TIMESTAMPTZ   NOT NULL,
  duration_min    INTEGER       NOT NULL DEFAULT 60,
  status          schedule_status NOT NULL DEFAULT 'Confirmado',
  notes           TEXT,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── Financeiro ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS finance_entries (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  company_id      TEXT          NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  description     TEXT          NOT NULL,
  category        TEXT          NOT NULL,
  type            finance_type  NOT NULL,
  amount          INTEGER       NOT NULL,   -- centavos
  status          finance_status NOT NULL DEFAULT 'Previsto',
  due_date        DATE,
  settled_at      TIMESTAMPTZ,
  notes           TEXT,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── Documentos ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS documents (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  company_id      TEXT          NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  client_id       TEXT          REFERENCES clients(id) ON DELETE SET NULL,
  weapon_id       TEXT          REFERENCES weapons(id) ON DELETE SET NULL,
  name            TEXT          NOT NULL,
  type            doc_type      NOT NULL,
  issued_at       DATE          NOT NULL,
  expires_at      DATE          NOT NULL,
  status          doc_status    NOT NULL DEFAULT 'Válido',
  file_url        TEXT,
  notes           TEXT,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── Faturas SaaS (Admin) ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS invoices (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  company_id      TEXT          NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  amount          INTEGER       NOT NULL,   -- centavos
  status          invoice_status NOT NULL DEFAULT 'Pendente',
  due_date        DATE          NOT NULL,
  paid_at         TIMESTAMPTZ,
  description     TEXT,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── Super-admins (plataforma) ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS super_admins (
  id              TEXT          PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  email           TEXT          UNIQUE NOT NULL,
  name            TEXT          NOT NULL,
  password_hash   TEXT          NOT NULL,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── Índices de performance ───────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_clients_company      ON clients(company_id);
CREATE INDEX IF NOT EXISTS idx_weapons_company      ON weapons(company_id);
CREATE INDEX IF NOT EXISTS idx_weapons_client       ON weapons(client_id);
CREATE INDEX IF NOT EXISTS idx_ammo_stock_company   ON ammo_stock(company_id);
CREATE INDEX IF NOT EXISTS idx_ammo_mov_company     ON ammo_movements(company_id);
CREATE INDEX IF NOT EXISTS idx_schedules_company    ON schedules(company_id);
CREATE INDEX IF NOT EXISTS idx_schedules_starts     ON schedules(starts_at);
CREATE INDEX IF NOT EXISTS idx_finance_company      ON finance_entries(company_id);
CREATE INDEX IF NOT EXISTS idx_documents_company    ON documents(company_id);
CREATE INDEX IF NOT EXISTS idx_documents_expires    ON documents(expires_at);
CREATE INDEX IF NOT EXISTS idx_invoices_company     ON invoices(company_id);
CREATE INDEX IF NOT EXISTS idx_app_users_company    ON app_users(company_id);

-- ─── Trigger: atualiza updated_at automaticamente ────────────────────────────
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

DO $$ 
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'plans','companies','app_users','clients','weapons',
    'ammo_stock','schedules','finance_entries','documents','invoices'
  ] LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS trg_updated_at ON %I;
       CREATE TRIGGER trg_updated_at
         BEFORE UPDATE ON %I
         FOR EACH ROW EXECUTE FUNCTION set_updated_at();',
      t, t
    );
  END LOOP;
END $$;
`;

async function migrate() {
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  try {
    await client.connect();
    console.log("🔗 Conectado ao banco. Executando migrações…");
    await client.query(SQL);
    console.log("✅ Migrações concluídas com sucesso.");
  } finally {
    await client.end();
  }
}

migrate().catch((err) => {
  console.error("❌ Erro na migração:", err);
  process.exit(1);
});
